(function(){
	"use strict";
	angular
	.module("ekart",[])
	.controller('MainCtrl',["$scope",function($scope){
		$scope.message = "as";
	}]);
});
